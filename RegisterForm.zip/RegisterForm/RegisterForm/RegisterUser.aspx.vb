﻿using System;
using System.Data.SqlClient;
Public Class RegisterUser
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        SqlConnection con=new SqlConnection(@"DataSource=DOTNET41-PC;Initial Catalog=ASpApplication;User ID=abc;Password=123");
    {
    con.Open();
        SqlCommand cmd=new SqlCommand("Insert into tbllogin values(@name,@pass,@city,@mail)",con);
        cmd.Parameters.AddWithValue("name",TextBox1.Text);
    cmd.Parameters.AddWithValue("pass",TextBox2.Text);
    cmd.Parameters.AddWithValue("city",DropDownList1.SelectedValue);
    cmd.Parameters.AddWithValue("mail",TextBox4.Text);
    cmd.ExecuteNonQuery();

    TextBox1.Text="";
     TextBox2.Text="";
    DropDownList.SelectedValue="";
    TextBox4.Text="";
    TextBox1.Focus();
 }
    End Sub
End Class